from neurolib import NeuralNetwork, Matrix, Dense, ActivationLayer, ReLU, Softmax

X = Matrix([[0., 0.], [0., 1.], [1., 0.], [1., 1.]])
y = Matrix([[1., 0.], [0., 1.], [0., 1.], [1., 0.]])

# --- Первый запуск: обучаем и сохраняем ---
print("=== Обучение ===")
net = NeuralNetwork([
    Dense(2, 8), ActivationLayer(ReLU()),
    Dense(8, 8), ActivationLayer(ReLU()),
    Dense(8, 2), ActivationLayer(Softmax()),
])
net.train(X, y, epochs=2000, lr=0.05)
print("\nПосле обучения:")
print(net.predict(X))

net.save("xor_model.json")

# --- Второй запуск: загружаем из файла ---
print("\n=== Загрузка из файла ===")
net2 = NeuralNetwork.load("xor_model.json")
print(net2.predict(X))