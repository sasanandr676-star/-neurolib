from neurolib import diagnose, rescue

# === Представим: чужие "плохие" данные ===
# Есть NaN, inf, большой разброс, мало примеров
data = [
    [1.0,   float('nan')],
    [2.0,   3.0],
    [0.5,   1000.0],       # выброс
    [1.5,   2.5],
    [float('inf'), 1.0],   # ещё плохое
    [0.8,   2.2],
    [1.2,   2.8],
    [1.8,   3.2],
]
labels = [0, 1, 1, 1, 0, 1, 1, 0]

# 1. Сначала — диагностика
diagnose.print_report(data, labels)

# 2. Потом — аварийное обучение
print("\n🚀 Пробуем обучить ИИ с нуля...")
net = rescue.emergency_train(data, labels, epochs=200, lr=0.1)

# 3. Проверяем результат
from neurolib import Matrix
test = Matrix([[1.0, 2.5], [0.6, 3.0]])
pred = net.predict(test)
print("\nПредсказания:")
for i, row in enumerate(pred.data):
    cls = row.index(max(row))
    print(f"  Пример {test.data[i]} → класс {cls} "
          f"(уверенность {max(row):.2%})")