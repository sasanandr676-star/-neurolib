from neurolib import NeuralNetwork, Matrix, Dense, ActivationLayer, ReLU, Softmax
from neurolib.russian import (
    build_vocab, fit_tfidf, text_to_tfidf, most_common_words
)

# === Данные: 3 темы ===
data = [
    # 0 = еда
    ("я люблю пиццу", 0), ("хочу поесть суп", 0),
    ("вкусный борщ", 0), ("приготовил ужин", 0),
    ("ем яблоко", 0), ("попробуй пирог", 0),
    ("чай с печеньем", 0), ("жарим картошку", 0),
    # 1 = программирование
    ("пишу код на python", 1), ("библиотека neurolib работает", 1),
    ("отладка функции", 1), ("ошибка в программе", 1),
    ("запустил скрипт", 1), ("массив и цикл", 1),
    ("градиентный спуск", 1), ("нейросеть обучается", 1),
    # 2 = погода
    ("сегодня солнечно", 2), ("идет дождь", 2),
    ("холодный ветер", 2), ("тепло на улице", 2),
    ("зимой снег", 2), ("летом жарко", 2),
    ("облачно и пасмурно", 2), ("прогноз погоды", 2),
]

texts = [t for t, _ in data]
labels = [l for _, l in data]

vocab = build_vocab(texts, max_size=50)
idf = fit_tfidf(texts, vocab)

print(f"Словарь: {len(vocab)} слов")
print("Топ-10 частых слов:", most_common_words(texts, top=10))
print()

X = Matrix([text_to_tfidf(t, vocab, idf) for t in texts])

def one_hot(lbl, n=3):
    return [1.0 if i == lbl else 0.0 for i in range(n)]

y = Matrix([one_hot(l) for l in labels])

net = NeuralNetwork([
    Dense(len(vocab), 16), ActivationLayer(ReLU()),
    Dense(16, 16), ActivationLayer(ReLU()),
    Dense(16, 3), ActivationLayer(Softmax()),
])

net.train(X, y, epochs=400, lr=0.1, batch_size=8)

CLASSES = ["еда", "программирование", "погода"]
tests = [
    "хочу пиццу с сыром",
    "код работает отлично",
    "сегодня снег и ветер",
    "на обед борщ",
    "запустил новую программу",
    "жарко и солнечно",
]

print("\n=== Проверка на новых фразах ===")
for phrase in tests:
    vec = Matrix([text_to_tfidf(phrase, vocab, idf)])
    pred = net.predict(vec)
    probs = pred.data[0]
    cls = probs.index(max(probs))
    print(f"  «{phrase}» → {CLASSES[cls]} "
          f"(уверенность {probs[cls]:.1%})")