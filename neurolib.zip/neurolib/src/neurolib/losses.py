"""Функции потерь. Без numpy."""
import math
from .matrix import Matrix


class MSE:
    def loss(self, y_pred, y_true):
        diff = y_pred - y_true
        return (diff * diff).mean()

    def grad(self, y_pred, y_true):
        n = y_pred.rows * y_pred.cols
        return (y_pred - y_true) * (2.0 / n)


class CrossEntropy:
    def loss(self, y_pred, y_true):
        eps = 1e-12
        total = 0.0
        count = 0
        for i in range(y_pred.rows):
            for j in range(y_pred.cols):
                total -= y_true.data[i][j] * math.log(y_pred.data[i][j] + eps)
            count += 1
        return total / count if count else 0.0

    def grad(self, y_pred, y_true):
        # работает в паре с Softmax: dL/dz = y_pred - y_true
        return y_pred - y_true