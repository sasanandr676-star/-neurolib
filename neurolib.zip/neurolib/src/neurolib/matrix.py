"""Простая матрица на списках — замена numpy для neurolib."""
import math
import random


class Matrix:
    def __init__(self, data):
        if isinstance(data, (int, float)):
            data = [[float(data)]]
        self.data = [[float(x) for x in row] for row in data]
        self.rows = len(self.data)
        self.cols = len(self.data[0]) if self.rows else 0

    # --- создание ---

    @staticmethod
    def zeros(rows, cols):
        return Matrix([[0.0] * cols for _ in range(rows)])

    @staticmethod
    def ones(rows, cols):
        return Matrix([[1.0] * cols for _ in range(rows)])

    @staticmethod
    def random(rows, cols, low=-1.0, high=1.0):
        return Matrix([[random.uniform(low, high) for _ in range(cols)]
                       for _ in range(rows)])

    # --- доступ ---

    def __getitem__(self, idx):
        return self.data[idx]

    def __setitem__(self, idx, value):
        self.data[idx] = value

    def shape(self):
        return (self.rows, self.cols)

    def copy(self):
        return Matrix([row[:] for row in self.data])

    # --- broadcasting ---

    def _get(self, i, j, target_rows, target_cols):
        ii = i if self.rows > 1 else 0
        jj = j if self.cols > 1 else 0
        return self.data[ii][jj]

    def _broadcast_shape(self, other):
        rows = max(self.rows, other.rows)
        cols = max(self.cols, other.cols)
        for m in (self, other):
            if m.rows not in (1, rows) or m.cols not in (1, cols):
                raise ValueError(
                    f"Несовместимые размеры: {self.shape()} и {other.shape()}"
                )
        return rows, cols

    # --- арифметика ---

    def __add__(self, other):
        if isinstance(other, (int, float)):
            return Matrix([[x + other for x in row] for row in self.data])
        rows, cols = self._broadcast_shape(other)
        return Matrix([[self._get(i, j, rows, cols) + other._get(i, j, rows, cols)
                        for j in range(cols)]
                       for i in range(rows)])

    def __sub__(self, other):
        if isinstance(other, (int, float)):
            return Matrix([[x - other for x in row] for row in self.data])
        rows, cols = self._broadcast_shape(other)
        return Matrix([[self._get(i, j, rows, cols) - other._get(i, j, rows, cols)
                        for j in range(cols)]
                       for i in range(rows)])

    def __mul__(self, other):
        if isinstance(other, (int, float)):
            return Matrix([[x * other for x in row] for row in self.data])
        rows, cols = self._broadcast_shape(other)
        return Matrix([[self._get(i, j, rows, cols) * other._get(i, j, rows, cols)
                        for j in range(cols)]
                       for i in range(rows)])

    def __rmul__(self, scalar):
        return self.__mul__(scalar)

    def __truediv__(self, scalar):
        return Matrix([[x / scalar for x in row] for row in self.data])

    def __neg__(self):
        return Matrix([[-x for x in row] for row in self.data])

    def __pow__(self, power):
        return Matrix([[x ** power for x in row] for row in self.data])

    # --- матричное умножение ---

    def dot(self, other):
        if self.cols != other.rows:
            raise ValueError(
                f"Несовместимые размеры для dot: {self.shape()} × {other.shape()}"
            )
        result = [[0.0] * other.cols for _ in range(self.rows)]
        for i in range(self.rows):
            row_a = self.data[i]
            row_r = result[i]
            for k in range(self.cols):
                a = row_a[k]
                if a == 0.0:
                    continue
                row_b = other.data[k]
                for j in range(other.cols):
                    row_r[j] += a * row_b[j]
        return Matrix(result)

    def transpose(self):
        return Matrix([[self.data[i][j] for i in range(self.rows)]
                       for j in range(self.cols)])

    # --- агрегаты ---

    def sum(self, axis=None):
        if axis is None:
            return sum(sum(row) for row in self.data)
        if axis == 0:
            return Matrix([[sum(self.data[i][j] for i in range(self.rows))
                            for j in range(self.cols)]])
        if axis == 1:
            return Matrix([[sum(row)] for row in self.data])
        raise ValueError("axis должен быть 0, 1 или None")

    def mean(self):
        n = self.rows * self.cols
        return self.sum() / n if n else 0.0

    def max(self, axis=None):
        if axis is None:
            return max(max(row) for row in self.data)
        if axis == 1:
            return Matrix([[max(row)] for row in self.data])
        raise ValueError("Поддерживается axis=1 или None")

    def apply(self, func):
        return Matrix([[func(x) for x in row] for row in self.data])

    # --- JSON ---

    def to_json(self):
        return self.data

    @staticmethod
    def from_json(data):
        return Matrix(data)

    # --- удобства ---

    def tolist(self):
        return [row[:] for row in self.data]

    def __repr__(self):
        return f"Matrix({self.shape()})"

    def __str__(self):
        lines = ["["]
        for row in self.data:
            lines.append("  [" + ", ".join(f"{x:7.4f}" for x in row) + "]")
        lines.append("]")
        return "\n".join(lines)