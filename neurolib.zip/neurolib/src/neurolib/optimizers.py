"""Оптимизаторы: SGD и Adam. Без numpy."""
from .matrix import Matrix


class SGD:
    def __init__(self, lr=0.01):
        self.lr = lr

    def step(self, layers):
        for layer in layers:
            if hasattr(layer, 'W'):
                layer.W = layer.W - layer.dW * self.lr
                layer.b = layer.b - layer.db * self.lr


class Adam:
    def __init__(self, lr=0.001, beta1=0.9, beta2=0.999, eps=1e-8):
        self.lr, self.beta1, self.beta2, self.eps = lr, beta1, beta2, eps
        self.m = {}
        self.v = {}
        self.t = 0

    def step(self, layers):
        self.t += 1
        for i, layer in enumerate(layers):
            if not hasattr(layer, 'W'):
                continue
            for name in ('W', 'b'):
                key = (i, name)
                param = getattr(layer, name)
                grad = getattr(layer, 'd' + name)

                if key not in self.m:
                    self.m[key] = Matrix.zeros(param.rows, param.cols)
                    self.v[key] = Matrix.zeros(param.rows, param.cols)

                self.m[key] = self.m[key] * self.beta1 + grad * (1 - self.beta1)
                self.v[key] = self.v[key] * self.beta2 + (grad * grad) * (1 - self.beta2)

                m_hat = self.m[key] / (1 - self.beta1 ** self.t)
                v_hat = self.v[key] / (1 - self.beta2 ** self.t)

                # param -= lr * m_hat / (sqrt(v_hat) + eps)
                update = m_hat * 1.0  # скопируем, чтобы применить поэлементную операцию
                update = update.apply(lambda _: 0.0)  # временный контейнер

                new_data = []
                for r in range(param.rows):
                    row = []
                    for c in range(param.cols):
                        mh = m_hat.data[r][c]
                        vh = v_hat.data[r][c]
                        row.append(param.data[r][c] - self.lr * mh / ((vh ** 0.5) + self.eps))
                    new_data.append(row)
                new_param = Matrix(new_data)
                setattr(layer, name, new_param)