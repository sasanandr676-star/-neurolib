"""Аварийный запуск и обучение ИИ.

Когда у пользователя плохие данные, мало примеров,
несовместимое окружение — rescue помогает запуститься всё равно.
"""
import math
from .matrix import Matrix
from .layers import Dense, ActivationLayer
from .activations import ReLU, Softmax
from .network import NeuralNetwork
from .guard import safe_train, clean_matrix


def detect_input_size(data):
    """Определить размер входа по данным."""
    if not data:
        return 0
    first = data[0]
    if isinstance(first, (list, tuple)):
        return len(first)
    return 1


def normalize_data(data):
    """Нормализовать данные в диапазон [0, 1]."""
    if not data or not data[0]:
        return data
    if not isinstance(data[0], (list, tuple)):
        data = [[x] for x in data]

    n_cols = len(data[0])
    cols = [[row[j] for row in data] for j in range(n_cols)]
    mins = [min(c) for c in cols]
    maxs = [max(c) for c in cols]
    ranges = [mx - mn if mx != mn else 1.0 for mn, mx in zip(mins, maxs)]

    return [[(row[j] - mins[j]) / ranges[j] for j in range(n_cols)]
            for row in data]


def one_hot(labels, n_classes):
    """One-hot кодирование меток."""
    result = []
    for lbl in labels:
        row = [0.0] * n_classes
        if 0 <= int(lbl) < n_classes:
            row[int(lbl)] = 1.0
        result.append(row)
    return result


def emergency_train(data, labels,
                    hidden_size=16,
                    n_classes=None,
                    epochs=300,
                    lr=0.05,
                    verbose=True):
    """Аварийное обучение на любых данных.

    Что делает:
    - определяет входной размер автоматически
    - нормализует данные
    - делает one-hot метки
    - строит сеть 2 слоя с ReLU + Softmax
    - обучает с защитой от NaN (safe_train)

    Аргументы:
    - data: список примеров (каждый — число или список чисел)
    - labels: список меток (числа от 0)
    - hidden_size: размер скрытого слоя
    - n_classes: сколько классов (если None — угадает по меткам)
    - epochs, lr: обучение
    """
    if not data:
        raise ValueError("Пустой набор данных")
    if len(data) != len(labels):
        # Обрезаем до минимума
        n = min(len(data), len(labels))
        data = data[:n]
        labels = labels[:n]
        if verbose:
            print(f"⚠️ Размеры не совпадали, обрезано до {n}")

    # Входной размер
    n_features = detect_input_size(data)
    if verbose:
        print(f"📊 Входных признаков: {n_features}")
        print(f"📊 Примеров: {len(data)}")

    # Нормализация
    data = normalize_data(data)
    data = [[float(x) if not (math.isnan(x) or math.isinf(x)) else 0.0
             for x in row] for row in data]

    # Классы
    if n_classes is None:
        n_classes = int(max(labels)) + 1
    if verbose:
        print(f"📊 Классов: {n_classes}")

    # One-hot
    y = one_hot(labels, n_classes)

    # Данные → Matrix
    X_m = Matrix(data)
    y_m = Matrix(y)

    # Архитектура
    net = NeuralNetwork([
        Dense(n_features, hidden_size), ActivationLayer(ReLU()),
        Dense(hidden_size, hidden_size), ActivationLayer(ReLU()),
        Dense(hidden_size, n_classes), ActivationLayer(Softmax()),
    ])

    # Обучение с защитой
    if verbose:
        print("🚑 Обучение (аварийный режим)...")
    safe_train(net, X_m, y_m, epochs=epochs, lr=lr, verbose=verbose)
    if verbose:
        print("✅ Готово")

    return net