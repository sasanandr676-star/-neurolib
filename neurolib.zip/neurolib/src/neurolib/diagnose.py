"""Диагностика данных перед обучением.

Отвечает на вопрос: "почему мой ИИ не работает?"
"""
import math


def check_data(data, labels=None):
    """Проверить данные и вернуть отчёт.

    Возвращает список строк-наблюдений.
    """
    report = []
    n = len(data)

    if n == 0:
        report.append("🔴 Данные пусты")
        return report

    # Формат
    first = data[0]
    is_matrix = isinstance(first, (list, tuple))
    n_features = len(first) if is_matrix else 1
    report.append(f"🟢 Примеров: {n}, признаков: {n_features}")

    # Размер
    if n < 20:
        report.append(f"🟡 Мало данных ({n} примеров). "
                      f"Сеть может не обучиться.")
    elif n < 100:
        report.append(f"🟢 Данных немного ({n}), но хватит.")
    else:
        report.append(f"🟢 Данных достаточно ({n}).")

    # Плохие значения
    nan_count = 0
    inf_count = 0
    for row in data:
        vals = row if is_matrix else [row]
        for v in vals:
            try:
                if math.isnan(v):
                    nan_count += 1
                elif math.isinf(v):
                    inf_count += 1
            except (TypeError, ValueError):
                pass

    if nan_count:
        report.append(f"🔴 NaN в данных: {nan_count} штук "
                      f"(нужно заменить)")
    if inf_count:
        report.append(f"🔴 inf в данных: {inf_count} штук")

    if not nan_count and not inf_count:
        report.append("🟢 Плохих значений (NaN/inf) не найдено.")

    # Масштаб
    if is_matrix:
        try:
            cols = list(zip(*data))
            mins = [min(c) for c in cols]
            maxs = [max(c) for c in cols]
            spreads = [mx - mn for mn, mx in zip(mins, maxs)]
            if any(s > 1000 for s in spreads):
                report.append("🟡 Большой разброс — стоит нормализовать.")
            else:
                report.append("🟢 Масштаб признаков приемлемый.")
        except (TypeError, ValueError):
            pass

    # Классы
    if labels is not None:
        try:
            unique = sorted(set(int(x) for x in labels))
            counts = {c: sum(1 for x in labels if int(x) == c) for c in unique}
            report.append(f"🟢 Классов: {len(unique)}, метки: {unique}")
            max_share = max(counts.values()) / len(labels)
            if max_share > 0.9:
                report.append(f"🟡 Дисбаланс классов: "
                              f"один класс занимает {max_share:.0%}. "
                              f"Сеть может игнорировать меньшинство.")
        except (TypeError, ValueError):
            report.append("🟡 Метки некорректны.")

    return report


def print_report(data, labels=None):
    """Напечатать отчёт в человекочитаемом виде."""
    print("=" * 50)
    print("🔍 Диагностика данных")
    print("=" * 50)
    for line in check_data(data, labels):
        print(" ", line)
    print("=" * 50)