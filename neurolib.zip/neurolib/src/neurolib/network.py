"""Сборка слоёв в нейросеть и цикл обучения. Без numpy."""
import json
import random
from .matrix import Matrix
from .losses import CrossEntropy


class NeuralNetwork:
    def __init__(self, layers, loss=None):
        self.layers = layers
        self.loss_fn = loss or CrossEntropy()

    def forward(self, x):
        for layer in self.layers:
            x = layer.forward(x)
        return x

    def backward(self, grad):
        for layer in reversed(self.layers):
            grad = layer.backward(grad)

    def train(self, X, y, epochs=100, lr=0.01, batch_size=32,
              optimizer=None, verbose=True):
        from .optimizers import SGD
        opt = optimizer or SGD(lr)
        n = X.rows

        for epoch in range(epochs):
            idx = list(range(n))
            random.shuffle(idx)

            for i in range(0, n, batch_size):
                batch_idx = idx[i:i + batch_size]
                xb = Matrix([X.data[k] for k in batch_idx])
                yb = Matrix([y.data[k] for k in batch_idx])

                pred = self.forward(xb)
                grad = self.loss_fn.grad(pred, yb)
                self.backward(grad)
                opt.step(self.layers)

            if verbose and epoch % max(1, epochs // 10) == 0:
                loss = self.loss_fn.loss(self.forward(X), y)
                print(f"epoch {epoch:4d}  loss={loss:.4f}")

    def predict(self, X):
        return self.forward(X)

    # --- сохранение и загрузка ---

    def save(self, path):
        data = {
            "version": "0.2.0",
            "layers": [layer.get_params() for layer in self.layers
                       if hasattr(layer, "get_params")],
        }
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
        print(f"Модель сохранена: {path}")

    @staticmethod
    def load(path):
        from .layers import Dense, ActivationLayer
        from .activations import ReLU, Sigmoid, Tanh, Softmax

        activations = {
            "ReLU": ReLU,
            "Sigmoid": Sigmoid,
            "Tanh": Tanh,
            "Softmax": Softmax,
        }

        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)

        layers = []
        for entry in data["layers"]:
            if entry["type"] == "Dense":
                layer = Dense(entry["in_features"], entry["out_features"])
                layer.set_params(entry)
                layers.append(layer)
            elif entry["type"] == "Activation":
                act_cls = activations[entry["activation"]]
                layers.append(ActivationLayer(act_cls()))

        return NeuralNetwork(layers)