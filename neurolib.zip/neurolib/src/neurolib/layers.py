"""Слои нейросети. Без numpy."""
from .matrix import Matrix


class Layer:
    def forward(self, x):
        raise NotImplementedError

    def backward(self, grad):
        raise NotImplementedError


class Dense(Layer):
    def __init__(self, in_features, out_features):
        limit = (6.0 / (in_features + out_features)) ** 0.5
        self.W = Matrix.random(in_features, out_features, -limit, limit)
        self.b = Matrix.zeros(1, out_features)
        self.x = None
        self.dW = None
        self.db = None

    def forward(self, x):
        self.x = x
        return x.dot(self.W) + self.b

    def backward(self, grad):
        self.dW = self.x.transpose().dot(grad)
        self.db = grad.sum(axis=0)
        return grad.dot(self.W.transpose())

    def get_params(self):
        return {
            "type": "Dense",
            "in_features": self.W.rows,
            "out_features": self.W.cols,
            "W": self.W.to_json(),
            "b": self.b.to_json(),
        }

    def set_params(self, params):
        self.W = Matrix.from_json(params["W"])
        self.b = Matrix.from_json(params["b"])


class ActivationLayer(Layer):
    def __init__(self, activation):
        self.act = activation
        self.x = None

    def forward(self, x):
        self.x = x
        return self.act.forward(x)

    def backward(self, grad):
        return grad * self.act.backward(self.x)

    def get_params(self):
        return {
            "type": "Activation",
            "activation": self.act.__class__.__name__,
        }