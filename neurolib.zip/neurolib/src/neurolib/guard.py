"""Защита во время обучения — чтобы нейросеть не падала.

Перехватывает типичные проблемы:
- NaN и inf в данных и градиентах
- взрыв градиентов
- падение learning rate
- ошибки в отдельных батчах
"""
import math
from .matrix import Matrix


def has_bad_values(matrix):
    """Проверить, есть ли в матрице NaN или inf."""
    for row in matrix.data:
        for x in row:
            if math.isnan(x) or math.isinf(x):
                return True
    return False


def clean_matrix(matrix, replace=0.0):
    """Заменить NaN/inf на безопасное значение."""
    new_data = []
    for row in matrix.data:
        new_row = []
        for x in row:
            if math.isnan(x) or math.isinf(x):
                new_row.append(replace)
            else:
                new_row.append(x)
        new_data.append(new_row)
    return Matrix(new_data)


def clip_gradients(layers, max_norm=5.0):
    """Обрезать градиенты, чтобы избежать их взрыва.

    max_norm — максимальная норма градиента (по всем слоям сразу).
    """
    total = 0.0
    for layer in layers:
        if hasattr(layer, 'dW') and layer.dW is not None:
            for row in layer.dW.data:
                for x in row:
                    total += x * x
    total = math.sqrt(total)

    if total > max_norm and total > 0:
        scale = max_norm / total
        for layer in layers:
            if hasattr(layer, 'dW') and layer.dW is not None:
                layer.dW = layer.dW * scale
            if hasattr(layer, 'db') and layer.db is not None:
                layer.db = layer.db * scale
    return total


def check_network_health(net):
    """Проверить, жива ли сеть (нет ли NaN в весах)."""
    for i, layer in enumerate(net.layers):
        if hasattr(layer, 'W'):
            if has_bad_values(layer.W) or has_bad_values(layer.b):
                return False, f"Слой {i}: NaN/inf в весах"
    return True, "OK"


def safe_train(net, X, y, epochs=100, lr=0.01, batch_size=32,
               optimizer=None, verbose=True, max_norm=5.0):
    """Обучение с защитой от NaN, взрыва градиентов и падений.

    Отличия от net.train():
    - чистит входные данные от NaN/inf
    - обрезает градиенты
    - если loss стал NaN — откатывает эпоху и уменьшает lr
    - не падает на отдельных батчах
    """
    from .optimizers import SGD

    # Чистим входы
    X = clean_matrix(X)
    y = clean_matrix(y)

    opt = optimizer or SGD(lr)
    n = X.rows
    cur_lr = lr

    # Сохраняем хорошие веса для возможного отката
    def snapshot(net):
        return [(layer.W.copy(), layer.b.copy())
                for layer in net.layers if hasattr(layer, 'W')]

    def restore(net, snap):
        for layer, (W, b) in zip(
                [l for l in net.layers if hasattr(l, 'W')], snap):
            layer.W = W
            layer.b = b

    good_state = snapshot(net)

    import random
    for epoch in range(epochs):
        idx = list(range(n))
        random.shuffle(idx)

        try:
            for i in range(0, n, batch_size):
                batch_idx = idx[i:i + batch_size]
                xb = Matrix([X.data[k] for k in batch_idx])
                yb = Matrix([y.data[k] for k in batch_idx])

                pred = net.forward(xb)
                if has_bad_values(pred):
                    continue  # пропускаем плохой батч

                grad = net.loss_fn.grad(pred, yb)
                if has_bad_values(grad):
                    continue

                net.backward(grad)
                clip_gradients(net.layers, max_norm=max_norm)
                opt.step(net.layers)

            # Проверка: не стало ли хуже
            loss = net.loss_fn.loss(net.forward(X), y)
            if math.isnan(loss) or math.isinf(loss):
                # откатываем и уменьшаем lr
                restore(net, good_state)
                cur_lr = max(cur_lr * 0.5, 1e-5)
                opt.lr = cur_lr
                if verbose:
                    print(f"epoch {epoch:4d}  ⚠️ NaN в loss, откат, lr → {cur_lr:.5f}")
            else:
                good_state = snapshot(net)
                if verbose and epoch % max(1, epochs // 10) == 0:
                    print(f"epoch {epoch:4d}  loss={loss:.4f}")

        except Exception as e:
            if verbose:
                print(f"epoch {epoch:4d}  ⚠️ ошибка в эпохе: {e}, пропуск")
            continue

    return net