"""Работа с русским текстом для neurolib. Без зависимостей.

Умеет:
- чистить текст
- работать с буквами (посимвольно)
- работать со словами (bag-of-words, tf-idf, стемминг)
- комбинировать буквы + слова в один вектор
"""
import math


# === Алфавит ===
LOWER = "абвгдеёжзийклмнопрстуфхцчшщъыьэюя"
UPPER = LOWER.upper()
PUNCT = " .,!?;:-—«»\"'()"


# === Очистка текста ===
def clean_text(text):
    """Привести текст к единому виду."""
    text = text.lower().replace("ё", "е")
    result = []
    for ch in text:
        if ch in LOWER or ch in PUNCT:
            result.append(ch)
        else:
            result.append(" ")
    out = "".join(result)
    while "  " in out:
        out = out.replace("  ", " ")
    return out.strip()


# === Посимвольное кодирование ===
CHAR_TO_IDX = {ch: i + 1 for i, ch in enumerate(LOWER + PUNCT)}
IDX_TO_CHAR = {i: ch for ch, i in CHAR_TO_IDX.items()}
VOCAB_SIZE = len(CHAR_TO_IDX) + 1  # +1 для "неизвестный"


def char_to_index(ch):
    return CHAR_TO_IDX.get(ch, 0)


def index_to_char(idx):
    return IDX_TO_CHAR.get(idx, "?")


def text_to_vector(text, length=32):
    """Текст → вектор фиксированной длины (посимвольно)."""
    text = clean_text(text)
    vec = [0.0] * length
    for i, ch in enumerate(text[:length]):
        vec[i] = char_to_index(ch) / VOCAB_SIZE
    return vec


# === Токенизация ===
def tokenize(text):
    """Разбить текст на слова (оставляем только буквы)."""
    text = clean_text(text)
    words = []
    current = []
    for ch in text:
        if ch.isalpha():
            current.append(ch)
        else:
            if current:
                words.append("".join(current))
                current = []
    if current:
        words.append("".join(current))
    return words


# === Стемминг (грубый, но полезный для русского) ===
_RUS_ENDINGS = [
    "иями", "ями", "ами", "ией", "иях", "ях", "ам", "ям", "ий", "ый",
    "ой", "ая", "яя", "ое", "ее", "ые", "ие", "ов", "ев", "ью", "ию",
    "ия", "ие", "ей", "ая", "ое", "у", "ю", "а", "я", "о", "е", "ы",
    "и", "й", "ь",
]


def stem(word):
    """Грубый стемминг: отсечь типичное русское окончание."""
    if len(word) <= 4:
        return word
    for end in _RUS_ENDINGS:
        if word.endswith(end) and len(word) - len(end) >= 3:
            return word[:-len(end)]
    return word


def stem_text(text):
    """Стемминг всех слов в тексте."""
    return [stem(w) for w in tokenize(text)]


# === Словарь слов ===
def build_vocab(texts, max_size=200, min_count=1):
    """Построить словарь частых слов (можно со стеммингом)."""
    counts = {}
    for t in texts:
        for w in stem_text(t):
            counts[w] = counts.get(w, 0) + 1
    items = [(w, c) for w, c in counts.items() if c >= min_count]
    items.sort(key=lambda kv: -kv[1])
    return [w for w, _ in items[:max_size]]


# === Bag-of-words ===
def text_to_bow(text, vocab):
    """Текст → вектор частот слов (доля каждого слова в тексте)."""
    stems = stem_text(text)
    total = len(stems) if stems else 1
    word_to_idx = {w: i for i, w in enumerate(vocab)}
    vec = [0.0] * len(vocab)
    for w in stems:
        if w in word_to_idx:
            vec[word_to_idx[w]] += 1.0 / total
    return vec


# === TF-IDF ===
def fit_tfidf(texts, vocab):
    """Посчитать IDF-веса слов по корпусу текстов.

    IDF = ln(N / (1 + df)),  где df — сколько документов содержат слово.
    """
    N = len(texts)
    df = [0] * len(vocab)
    word_to_idx = {w: i for i, w in enumerate(vocab)}
    for t in texts:
        seen = set()
        for w in stem_text(t):
            if w in word_to_idx and w not in seen:
                df[word_to_idx[w]] += 1
                seen.add(w)
    idf = [math.log(N / (1 + d)) if d > 0 else 0.0 for d in df]
    return idf


def text_to_tfidf(text, vocab, idf):
    """Текст → tf-idf вектор."""
    bow = text_to_bow(text, vocab)
    return [bow[i] * idf[i] for i in range(len(bow))]


# === Гибрид: буквы + слова ===
def text_to_hybrid(text, vocab, char_len=16, word_weight=1.0):
    """Комбинация: [буквы] + [слова * word_weight]."""
    chars = text_to_vector(text, length=char_len)
    words = text_to_bow(text, vocab)
    return chars + [w * word_weight for w in words]


# === Язык ===
def has_cyrillic(text):
    return any(ch in LOWER or ch in UPPER for ch in text)


def language_guess(text):
    letters = [ch for ch in text if ch.isalpha()]
    if not letters:
        return "unknown"
    cyr = sum(1 for ch in letters if ch in LOWER or ch in UPPER)
    return "ru" if cyr / len(letters) > 0.5 else "not_ru"


# === Аналитика ===
def word_stats(text):
    """Статистика по тексту: слов, уникальных, средняя длина."""
    words = tokenize(text)
    uniq = set(words)
    avg_len = sum(len(w) for w in words) / len(words) if words else 0.0
    return {
        "words": len(words),
        "unique": len(uniq),
        "avg_len": round(avg_len, 2),
    }


def most_common_words(texts, top=10):
    """Топ-N самых частых слов в корпусе."""
    from collections import Counter
    c = Counter()
    for t in texts:
        c.update(stem_text(t))
    return c.most_common(top)