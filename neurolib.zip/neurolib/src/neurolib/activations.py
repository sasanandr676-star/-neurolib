"""Функции активации и их производные. Без numpy."""
import math
from .matrix import Matrix


class Activation:
    def forward(self, x: Matrix) -> Matrix:
        raise NotImplementedError

    def backward(self, x: Matrix) -> Matrix:
        raise NotImplementedError


class ReLU(Activation):
    def forward(self, x):
        return x.apply(lambda v: v if v > 0 else 0.0)

    def backward(self, x):
        return x.apply(lambda v: 1.0 if v > 0 else 0.0)


class Sigmoid(Activation):
    def forward(self, x):
        return x.apply(lambda v: 1.0 / (1.0 + math.exp(-max(-500.0, min(500.0, v)))))

    def backward(self, x):
        return x.apply(lambda v: (lambda s: s * (1 - s))(
            1.0 / (1.0 + math.exp(-max(-500.0, min(500.0, v))))
        ))


class Tanh(Activation):
    def forward(self, x):
        return x.apply(math.tanh)

    def backward(self, x):
        return x.apply(lambda v: 1.0 - math.tanh(v) ** 2)


class Softmax(Activation):
    def forward(self, x):
        result = []
        for row in x.data:
            m = max(row)
            exps = [math.exp(v - m) for v in row]
            s = sum(exps)
            result.append([e / s for e in exps])
        return Matrix(result)

    def backward(self, x):
        # используется вместе с CrossEntropy — градиент упрощён
        return Matrix.ones(x.rows, x.cols)